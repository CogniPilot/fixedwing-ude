/* tslint:disable */
/* eslint-disable */

/**
 * Return the GALEC definition location for a UTF-16 LSP position, or `null`.
 */
export function galec_definition(source: string, file_name: string, uri: string, line: number, character: number): string;

/**
 * Compute GALEC `.alg` LSP diagnostics and return them as JSON.
 */
export function galec_diagnostics(source: string, file_name: string): string;

/**
 * Return GALEC hover information for a UTF-16 LSP position, or `null`.
 */
export function galec_hover(source: string, file_name: string, line: number, character: number): string;

/**
 * Initialize the panic hook for readable console errors (mirrors the core
 * binding and the diffsol addon).
 */
export function init(): void;

/**
 * Compile the workspace Modelica sources, project the model named
 * `model_name` to GALEC, and return the rendered artifacts as a JSON string.
 *
 * `workspace_sources` is a JSON object mapping each document path to its
 * Modelica text (`{ "<path>": "<content>", … }`) — the SAME map the core
 * binding compiles with, so a model spanning several files (imports, a
 * library, a non-active file) projects to GALEC exactly as it compiles for
 * every other target. `target` is one of `galec`, `galec-production`,
 * `embedded-c-galec`.
 *
 * Success shape:
 * ```json
 * { "ok": true, "target": "<target>", "model_identifier": "<id>",
 *   "alg": "<.alg text>", "c_header": "<.h text or empty>",
 *   "c_source": "<.c text or empty>" }
 * ```
 * The `c_header`/`c_source` fields are empty strings for the `galec` target
 * (Algorithm Code only). Failure shape: `{ "ok": false, "error": "<msg>" }`.
 */
export function render_galec(workspace_sources: string, model_name: string, target: string): string;

/**
 * Parse an edited GALEC `.alg` block and render GALEC-derived C files.
 *
 * This is the editor-owned second step for the docs/playground flow:
 * Modelica projection produces editable `.alg`; this function consumes the
 * current `.alg` text and emits `.h`/`.c` without re-reading the Modelica
 * source. It is intentionally source-only: the eFMI container and Production
 * Code manifests remain the native CLI packaging step.
 */
export function render_galec_c_from_alg(alg_source: string, file_name: string, model_name: string, target: string): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly galec_definition: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number];
    readonly galec_diagnostics: (a: number, b: number, c: number, d: number) => [number, number];
    readonly galec_hover: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly render_galec: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly render_galec_c_from_alg: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number];
    readonly init: () => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
