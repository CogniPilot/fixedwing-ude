/* tslint:disable */
/* eslint-disable */

/**
 * Opaque handle to a real-time simulation session running in WASM.
 *
 * Compiles a Modelica model and creates an interactive session that can be
 * driven from JavaScript via `requestAnimationFrame`.
 */
export class WasmSimulationSession {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Advance the simulation to an absolute target time in seconds.
     */
    advance_to(target_time: number): void;
    /**
     * Get the configured final simulation time.
     */
    end_time(): number;
    /**
     * Read a single variable value by name.
     */
    get(name: string): number | undefined;
    /**
     * Get available input names as a JSON array string.
     */
    input_names(): string;
    /**
     * Compile a Modelica model and create a session ready for interactive use.
     *
     * `source` is the full Modelica source text and `model_name` is the class
     * to simulate. The model's experiment metadata supplies default simulation
     * options.
     */
    constructor(source: string, model_name: string);
    /**
     * Reset the simulation to initial conditions.
     */
    reset(): void;
    /**
     * Reset to time zero and replace continuous states from a JSON object
     * mapping canonical state names to finite numeric values.
     */
    reset_with_state(values_json: string): void;
    /**
     * Set an input value by name. Takes effect on the next advance.
     */
    set_input(name: string, value: number): void;
    /**
     * Get all current variable values as a JSON string `{"time": t, "values": {...}}`.
     */
    state_json(): string;
    /**
     * Get canonical continuous-state names as a JSON array string.
     */
    state_names(): string;
    /**
     * Advance the simulation by a relative time step in seconds.
     */
    step(dt: number): void;
    /**
     * Get the current simulation time.
     */
    time(): number;
    /**
     * Get all solver variable names as a JSON array string.
     */
    variable_names(): string;
    /**
     * Compile a Modelica model and create a session with explicit simulation options.
     */
    static withOptions(source: string, model_name: string, t_end: number, dt: number, solver: string, atol: number, rtol: number): WasmSimulationSession;
}

/**
 * Check Modelica source code and return all diagnostics.
 */
export function check(source: string): any;

export function clear_source_root_cache(): void;

/**
 * Compile Modelica source code to DAE JSON.
 */
export function compile(source: string, model_name: string): string;

export function compile_check_with_source_roots(source: string, model_name: string, source_roots_json: string): string;

/**
 * Strict compile-check using loaded source roots with explicit behavior options.
 *
 * This validates requested-model compilation without producing full DAE output.
 * Option semantics are identical to `compile_with_source_roots_with_options`.
 */
export function compile_check_with_source_roots_with_options(source: string, model_name: string, source_roots_json: string, compile_options_json: string): string;

/**
 * Compile Modelica source code to DAE JSON (alias for worker compatibility).
 */
export function compile_to_json(source: string, model_name: string): string;

export function compile_with_source_roots(source: string, model_name: string, source_roots_json: string): string;

/**
 * Compile using loaded source roots with explicit compile behavior options.
 *
 * `compile_options_json` example:
 * `{"allowNonParamEvaluateAnnotation":true,"allowMultiWhenSingleAssign":false}`
 *
 * Strict behavior remains default when this function is not used (or options are false).
 */
export function compile_with_source_roots_with_options(source: string, model_name: string, source_roots_json: string, compile_options_json: string): string;

export function compile_with_workspace_sources(source: string, model_name: string, workspace_sources_json: string): string;

export function export_parsed_source_roots_binary(uris_json: string): Uint8Array;

/**
 * Get the UTC build timestamp for this WASM build.
 */
export function get_build_time_utc(): string;

/**
 * Get the built-in codegen targets bundled with the WASM runtime.
 */
export function get_builtin_targets(): any;

export function get_bundled_source_root_manifest(): string;

/**
 * Get detailed class documentation and summary metadata.
 */
export function get_class_info(qualified_name: string): string;

/**
 * Get the Git commit hash for this WASM build.
 */
export function get_git_commit(): string;

/**
 * Discover compilable simulation models in a source document.
 */
export function get_simulation_models(source: string, default_model: string): string;

export function get_source_root_document_count(): number;

export function get_source_root_statuses(): string;

/**
 * Get the Rumoca version string.
 */
export function get_version(): string;

/**
 * Initialize panic hook for better error messages in console.
 */
export function init(): void;

/**
 * Lint Modelica source code and return messages.
 */
export function lint(source: string): any;

/**
 * List all loaded classes as a package/class hierarchy.
 */
export function list_classes(): string;

export function load_bundled_source_root_cache(archive_id: string): number;

export function load_source_roots(source_roots_json: string): string;

/**
 * Compile a model and return its lowered `SolveModel` as JSON, for the lazy
 * diffsol addon (`@cognipilot/rumoca/diffsol`) to simulate. Lets the stiff
 * solver run without putting relaxed-SIMD in this (universal) module.
 */
export function lower_model_to_solve_json(source: string, model_name: string, t_end: number, dt: number, parameter_overrides_json: string): string;

/**
 * Get code actions (quick fixes) for diagnostics in a selected range.
 */
export function lsp_code_actions(source: string, range_start_line: number, range_start_character: number, range_end_line: number, range_end_character: number, diagnostics_json: string): string;

/**
 * Get code completion suggestions.
 */
export function lsp_completion(source: string, line: number, character: number): string;

/**
 * Get code completion suggestions plus the completion timing breakdown used by the benchmark.
 */
export function lsp_completion_with_timing(source: string, line: number, character: number): string;

/**
 * Get go-to-definition target(s) for a position.
 */
export function lsp_definition(source: string, line: number, character: number): string;

/**
 * Compute diagnostics (syntax, lint, and compilation errors).
 */
export function lsp_diagnostics(source: string): string;

/**
 * Get document symbols (outline).
 */
export function lsp_document_symbols(source: string): string;

/**
 * Get hover information for a position.
 */
export function lsp_hover(source: string, line: number, character: number): string;

/**
 * Get the semantic token legend.
 */
export function lsp_semantic_token_legend(): string;

/**
 * Get semantic tokens for syntax highlighting.
 */
export function lsp_semantic_tokens(source: string): string;

export function merge_parsed_source_roots(definitions_json: string): number;

export function merge_parsed_source_roots_binary(bytes: Uint8Array): number;

/**
 * Compile a model and return tunable scalar parameter metadata as JSON.
 */
export function model_parameter_metadata(source: string, model_name: string): string;

/**
 * Compile with additional source-root libraries and return parameter metadata.
 */
export function model_parameter_metadata_with_source_roots(source: string, model_name: string, source_roots_json: string): string;

/**
 * Compile with additional workspace-local sources and return parameter metadata.
 */
export function model_parameter_metadata_with_workspace_sources(source: string, model_name: string, workspace_sources_json: string): string;

/**
 * Parse Modelica source code and return whether it's valid.
 */
export function parse(source: string): any;

export function parse_source_root_file(source: string, filename: string): string;

/**
 * Prepare a model for WebGPU execution.
 *
 * Compiles `source`, lowers it to the Solve IR with simulation defaults
 * (honoring the model's `experiment` annotation like `simulate_model`),
 * renders the `wgsl-solve` builtin target, and returns a JSON object:
 *
 * ```json
 * {
 *   "wgsl": "...compute shader source...",
 *   "layout": { ...the wgsl-solve layout manifest... },
 *   "y0": [..], "p0": [..],
 *   "n_states": 3,
 *   "t_start": 0.0, "t_end": 1.0,
 *   "dt": 0.1,
 *   "internal_dt": 0.0125
 * }
 * ```
 *
 * v1 semantics: the host integrates the first `n_states` entries of `y`;
 * the remaining (algebraic) slots and all parameters - including relation
 * memory - stay frozen at their prepared initial values. The layout's
 * `runtime_event_roots` count lets hosts warn when that matters.
 */
export function prepare_gpu_simulation(source: string, model_name: string): string;

export function prime_source_root_completion_cache(): number;

export function render_target(dae_json: string, model_name: string, target: string, manifest_source: string, templates_json: string): any;

/**
 * Default colocated `rumoca-scenario.<model>.toml` (`{ ok, path, content }`)
 * for a create-config action on a Modelica model.
 */
export function scenario_default_scenario_config(workspace_sources_json: string, model: string, task: string): string;

/**
 * Configured `[codegen]` target settings for a model (`{ target, outputDir }`).
 */
export function scenario_get_codegen_config(workspace_sources_json: string, model: string): string;

/**
 * Parse a single `rumoca-scenario.toml` scenario file (by workspace path) into the editor's
 * scenario descriptor (`task`, `model`, `viewerMode`, interactive ports, ...).
 */
export function scenario_get_scenario_config(workspace_sources_json: string, path: string): string;

/**
 * Full `rumoca-scenario.toml` scenario as a JSON tree for the config GUI:
 * `{ ok, config: <toml-as-json>, descriptor }`. The `config` tree round-trips
 * every section (including nested interactive-IO) losslessly.
 */
export function scenario_get_scenario_config_full(workspace_sources_json: string, path: string): string;

/**
 * Effective + preset + default simulation settings for a model, given the
 * workspace's `rumoca-scenario.toml` files and an optional editor `fallback` settings JSON.
 */
export function scenario_get_simulation_config(workspace_sources_json: string, model: string, fallback_json: string): string;

/**
 * Scenario-local source roots configured for a model (`{ sourceRootPaths }`).
 */
export function scenario_get_source_roots(workspace_sources_json: string, model: string, task: string): string;

/**
 * Configured plot/visualization views for a model (`{ views: [...] }`).
 */
export function scenario_get_visualization_config(workspace_sources_json: string, model: string): string;

/**
 * Clear a model's simulation preset. Returns `{ writes, result }`.
 */
export function scenario_reset_simulation_preset(workspace_sources_json: string, model: string): string;

/**
 * Write a model's `[codegen]` target settings. Returns `{ writes, result }`.
 */
export function scenario_set_codegen_config(workspace_sources_json: string, model: string, codegen_json: string): string;

/**
 * Render a `rumoca-scenario.toml` from the config GUI's JSON tree. Returns
 * `{ writes: [{path, content}], result }` for the editor to apply.
 */
export function scenario_set_scenario_config(path: string, config_json: string): string;

/**
 * Write a model's simulation preset into its colocated `rum.<model>.toml`.
 * Returns `{ writes, result }` for the editor to apply to its workspace store.
 */
export function scenario_set_simulation_preset(workspace_sources_json: string, model: string, preset_json: string): string;

/**
 * Write a model's scenario-local source roots. Returns `{ writes, result }`.
 */
export function scenario_set_source_roots(workspace_sources_json: string, model: string, source_roots_json: string): string;

/**
 * Write a model's plot/visualization views. Returns `{ writes, result }`.
 */
export function scenario_set_visualization_config(workspace_sources_json: string, model: string, views_json: string): string;

/**
 * Compile and simulate a Modelica model.
 */
export function simulate_model(source: string, model_name: string, t_end: number, dt: number, solver: string, parameter_overrides_json: string): string;

/**
 * Compile with additional source-root libraries and simulate a Modelica model.
 */
export function simulate_model_with_source_roots(source: string, model_name: string, source_roots_json: string, t_end: number, dt: number, solver: string, parameter_overrides_json: string): string;

/**
 * Compile with additional workspace-local sources and simulate a Modelica model.
 */
export function simulate_model_with_workspace_sources(source: string, model_name: string, workspace_sources_json: string, t_end: number, dt: number, solver: string, parameter_overrides_json: string): string;

export function sync_workspace_sources(workspace_sources_json: string): string;

/**
 * Re-settle prepared vectors for new parameter values. The initial GPU prepare
 * uses lean lowering, so updates perform full runtime lowering on demand.
 * `overrides_json` is a `{ "name": value }` object naming scalar parameters.
 * Returns `{ "y0": [...], "p0": [...] }`.
 */
export function update_gpu_parameters(source: string, model_name: string, overrides_json: string): string;

/**
 * Fallback thread-pool initializer for non-threaded builds.
 */
export function wasm_init(_num_threads: number): boolean;

export function workspace_effective_source_roots(workspace_sources_json: string, focus_path: string): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly check: (a: number, b: number) => [number, number, number];
    readonly compile: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly compile_to_json: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly get_build_time_utc: () => [number, number];
    readonly get_builtin_targets: () => [number, number, number];
    readonly get_class_info: (a: number, b: number) => [number, number, number, number];
    readonly get_git_commit: () => [number, number];
    readonly get_simulation_models: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly get_version: () => [number, number];
    readonly lint: (a: number, b: number) => [number, number, number];
    readonly list_classes: () => [number, number, number, number];
    readonly lower_model_to_solve_json: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly lsp_code_actions: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly lsp_completion: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly lsp_completion_with_timing: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly lsp_definition: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly lsp_diagnostics: (a: number, b: number) => [number, number, number, number];
    readonly lsp_document_symbols: (a: number, b: number) => [number, number, number, number];
    readonly lsp_hover: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly lsp_semantic_token_legend: () => [number, number, number, number];
    readonly lsp_semantic_tokens: (a: number, b: number) => [number, number, number, number];
    readonly model_parameter_metadata: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly model_parameter_metadata_with_source_roots: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly model_parameter_metadata_with_workspace_sources: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly parse: (a: number, b: number) => [number, number, number];
    readonly render_target: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => [number, number, number];
    readonly scenario_default_scenario_config: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly scenario_get_codegen_config: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly scenario_get_scenario_config: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly scenario_get_scenario_config_full: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly scenario_get_simulation_config: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly scenario_get_source_roots: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly scenario_get_visualization_config: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly scenario_reset_simulation_preset: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly scenario_set_codegen_config: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly scenario_set_scenario_config: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly scenario_set_simulation_preset: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly scenario_set_source_roots: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly scenario_set_visualization_config: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly simulate_model: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => [number, number, number, number];
    readonly simulate_model_with_source_roots: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number) => [number, number, number, number];
    readonly simulate_model_with_workspace_sources: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number) => [number, number, number, number];
    readonly wasm_init: (a: number) => number;
    readonly init: () => void;
    readonly prepare_gpu_simulation: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly update_gpu_parameters: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly workspace_effective_source_roots: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly __wbg_wasmsimulationsession_free: (a: number, b: number) => void;
    readonly clear_source_root_cache: () => [number, number];
    readonly compile_check_with_source_roots: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly compile_check_with_source_roots_with_options: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly compile_with_source_roots: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly compile_with_source_roots_with_options: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly compile_with_workspace_sources: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly export_parsed_source_roots_binary: (a: number, b: number) => [number, number, number, number];
    readonly get_bundled_source_root_manifest: () => [number, number];
    readonly get_source_root_document_count: () => [number, number, number];
    readonly get_source_root_statuses: () => [number, number, number, number];
    readonly load_bundled_source_root_cache: (a: number, b: number) => [number, number, number];
    readonly load_source_roots: (a: number, b: number) => [number, number, number, number];
    readonly merge_parsed_source_roots: (a: number, b: number) => [number, number, number];
    readonly merge_parsed_source_roots_binary: (a: number, b: number) => [number, number, number];
    readonly parse_source_root_file: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly prime_source_root_completion_cache: () => [number, number, number];
    readonly sync_workspace_sources: (a: number, b: number) => [number, number, number, number];
    readonly wasmsimulationsession_advance_to: (a: number, b: number) => [number, number];
    readonly wasmsimulationsession_end_time: (a: number) => number;
    readonly wasmsimulationsession_get: (a: number, b: number, c: number) => [number, number, number, number];
    readonly wasmsimulationsession_input_names: (a: number) => [number, number, number, number];
    readonly wasmsimulationsession_new: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly wasmsimulationsession_reset: (a: number) => [number, number];
    readonly wasmsimulationsession_reset_with_state: (a: number, b: number, c: number) => [number, number];
    readonly wasmsimulationsession_set_input: (a: number, b: number, c: number, d: number) => [number, number];
    readonly wasmsimulationsession_state_json: (a: number) => [number, number, number, number];
    readonly wasmsimulationsession_state_names: (a: number) => [number, number, number, number];
    readonly wasmsimulationsession_step: (a: number, b: number) => [number, number];
    readonly wasmsimulationsession_time: (a: number) => number;
    readonly wasmsimulationsession_variable_names: (a: number) => [number, number, number, number];
    readonly wasmsimulationsession_withOptions: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => [number, number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
